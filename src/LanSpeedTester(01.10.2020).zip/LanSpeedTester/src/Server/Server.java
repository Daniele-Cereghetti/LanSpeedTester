package Server;

import java.net.*;
import java.io.*;
/**
 * Classe che permette ad un calcolatore di assumere il ruolo di server.
 * @author daniele.cereghetti
 * @version 24.09.2020
 */
public class Server {
    
    /**
     * Attiburo che indica la porta sulla quale il server sta ascoltando.
     */
    private int port;
    
    /**
     * Numero di thred che il server dovra aprire.
     */
    private int nThread;
    
    /**
     * Attriburo che indica l'ip del client
     */
    private Inet4Address ipClient;
    
    /**
     * Attributo che indica se il client sta trasmettendo.
     */
    private boolean trasmetting;
    
    /**
     * Attributo che indica se il client è connesso oppure no.
     */
    private boolean connacted;
    
    /**
     * Attributo che indica la dimensione dei dati che riceverà.
     */
    private int dimData;

    /**
     * Get the value of dimData
     * @return the value of dimData
     */
    public int getDimData() {
        return dimData;
    }

    /**
     * Set the value of dimData
     * @param dimData new value of dimData
     */
    public void setDimData(int dimData) {
        if(dimData >= 32){
            this.dimData = dimData;
        }
    }

    /**
     * Get the value of connacted
     * @return the value of connacted
     */
    public boolean isConnacted() {
        return connacted;
    }

    /**
     * Set the value of connacted
     * @param connacted new value of connacted
     */
    public void setConnacted(boolean connacted) {
        this.connacted = connacted;
    }

    /**
     * Get the value of trasmetting
     * @return the value of trasmetting
     */
    public boolean isTrasmetting() {
        return trasmetting;
    }

    /**
     * Set the value of trasmetting
     * @param trasmetting new value of trasmetting
     */
    public void setTrasmetting(boolean trasmetting) {
        this.trasmetting = trasmetting;
    }

    /**
     * Get the value of ipClient
     * @return the value of ipClient
     */
    public Inet4Address getIpClient() {
        return ipClient;
    }

    /**
     * Set the value of ipClient
     * @param ipClient new value of ipClient
     */
    public void setIpClient(Inet4Address ipClient) {
        this.ipClient = ipClient;
    }

    /**
     * Get the value of nThread.
     * @return the value of nThread
     */
    public int getnThread() {
        return nThread;
    }

    /**
     * Set the value of nThread.
     * @param nThread new value of nThread
     */
    public void setnThread(int nThread) {
       if(nThread >= 1024 && nThread <= 65535){
            this.nThread = nThread;
        }
    }

    /**
     * Get the value of port
     * @return the value of port
     */
    public int getPort() {
        return port;
    }

    /**
     * Set the value of port
     * @param port new value of port
     */
    public void setPort(int port) {
        if(port >= 1024 && port <= 65535){
            this.port = port;
        }
    }

    /**
     * Costruttore personalizzato.
     * @param port sulla quale il server ascolterà
     */
    public Server(int port) {
        this.port = port;
    }
    
    /**
     * Metodo fa aspetta nell'attesa di un client, ne prende i dati,
     * riceve dei dati utili al programma. 
     * @return se un client si è connesso
     */
    public boolean testClient(){
        try{
            //apertura e ascolto server
            ServerSocket svr = new ServerSocket(port);
            Socket socket = svr.accept();
            setConnacted(true);
            //lettura dati client
            InputStream input = socket.getInputStream();
            BufferedReader dataClient = new BufferedReader(
                    new InputStreamReader(input));
            //trasformazione dati client
            String text = dataClient.readLine();
            String thread = text.substring(0,text.indexOf(";"));
            String dimensionData = text.substring(text.indexOf(";")+1);
            //salvataggio dati ricevuti
            setnThread(Integer.parseInt(thread));
            setDimData(Integer.parseInt(dimensionData));
            System.out.println(socket.getLocalAddress().toString());
            //chiusura della porta d'ascolto
            svr.close();
        }catch(IOException | IndexOutOfBoundsException e){
            System.out.println(e.getMessage());
            return false;
        }
        getClientStatus();
        return true;        
    }

    
    
    
    /**
     * Metodo che stampa a terminale lo stato del client.
     * possibile miglioramento stampando direttamente
     */
    public void getClientStatus() {
        String ris;
        if(isTrasmetting()){
            ris = "Inizio del test...";
        }else if(isConnacted() && isTrasmetting()){
            ris = "fine del test";
        }else if(isConnacted() && !isTrasmetting()){
            ris = "Client connesso: " + getIpClient().toString() + 
                    ", dimensione dati: " + getDimData();
        }else{
            ris = "Client non connesso";
        }
        System.out.println(ris);
    }
}